from __future__ import division, absolute_import, print_function

from .. import __doc__

depends = ['core']
